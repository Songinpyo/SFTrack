# Refined UAVDT Test Annotations

This contains refined test annotations for the UAVDT (Unmanned Aerial Vehicle Detection and Tracking) dataset.
These annotations address and correct various issues found in the original dataset's test set annotations.
The refined annotations are available at: [SFTrack Repo](https://github.com/Songinpyo/SFTrack)


## Overview

- Total refined frames: 4,721
- Additional annotations: 43,981
- Total object count: 384,887 (increased from 340,906)
- Additional tracks: 55

## Improvements

The refined annotations address several key issues identified in the original UAVDT test set:

1. **Missing Object Annotations**: We identified and added annotations for previously unmarked objects
2. **Temporal Consistency**: Corrected annotations that:
  - Started before object appearance
  - Continued after object disappeared from frame
3. **Enhanced Tracking**: Added 55 new tracks for improved object tracking consistency

## Contents

- `annotations/`: Directory containing refined annotation files
- `README.md`: This file

## Usage

The annotation format follows the original UAVDT dataset structure for consistency.

## Citation

If you use these refined annotations in your research, please cite:

```bibtex
@article{song2024sftrack,
   title={SFTrack: A Robust Scale and Motion Adaptive Algorithm for Tracking Small and Fast Moving Objects},
   author={Song, InPyo and Lee, Jangwon},
   journal={arXiv preprint arXiv:2410.20079},
   year={2024}
}
```

Please also cite the original UAVDT dataset:

```bibtex
@inproceedings{du2018unmanned,
  title={The unmanned aerial vehicle benchmark: Object detection and tracking},
  author={Du, Dawei and Qi, Yuankai and Yu, Hongyang and Yang, Yifan and Duan, Kaiwen and Li, Guorong and Zhang, Weigang and Huang, Qingming and Tian, Qi},
  booktitle={Proceedings of the European Conference on Computer Vision (ECCV)},
  pages={370--386},
  year={2018}
}
```